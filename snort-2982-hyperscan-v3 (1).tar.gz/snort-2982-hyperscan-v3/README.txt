This README documents the attached patch to add Hyperscan acceleration support
for a number of pattern matching tasks in Snort. It has been tested against
Snort 2.9.8.2 and Snort 2.9.9.0.

It uses Hyperscan in three modules within Snort:

1. A multi-pattern (MPSE) literal matcher, called "hyperscan".
2. A faster single-pattern content string matcher, replacing the Boyer-Moore
   approach used by default.
3. A prefilter for PCRE, where Hyperscan is used as a prefilter check for regex
   options before PCRE is run. Expressions that are expensive to evaluate
   in PCRE may be avoided if the Hyperscan prefilter does not match.

The following is a quick guide to applying and using the patch.

----

1. Get Hyperscan

The source code to the Hyperscan library can be downloaded from:

    https://01.org/hyperscan

See the Developer Guide for instructions on how to build the library. This
patch (v3) has been tested against Hyperscan 4.3.2.

2. Apply the patch to a Snort tree

After downloading and unpacking Snort, the Hyperscan patch can be applied as
follows:

    $ cd snort-2.9.8.2
    $ zcat <path>/snort-2982-hyperscan.patch-v3.gz | patch -p2

Since this patch adds some options to configure.in, you will need to regenerate
the configure script and other autotools files:

    $ autoreconf -fi

Then, to setup a build with Hyperscan, you should configure and build Snort
with the new configure arguments, as shown below. Note that these assume that
Hyperscan has been built and installed in /opt/hyperscan-4.3.2/.

    $ ./configure --enable-intel-hyperscan \
            --with-intel-hyperscan-includes=/opt/hyperscan-4.3.2/include/hs \
            --with-intel-hyperscan-libraries=/opt/hyperscan-4.3.2/lib \
            <any other configure arguments>
    $ make

3. Configure Snort to use the Hyperscan MPSE matcher

The built Snort binary will use Hyperscan by default to scan for single content
and PCRE options.  To enable the use of the Hyperscan MPSE matcher for bulk
literal scanning, change the "config detection" option in your snort.conf:

    config detection: search-method hyperscan split-any-any

----

If you have questions, bug reports or other feedback, please contact the
Hyperscan team, either on the Hyperscan mailing list or directly. Contact
information is available at <https://01.org/hyperscan>.
